class task3{// display the data of student where is stroe already in computer
    public static void main(String[] args) {
        // Variables for student attributes
        String name = "Baran";             // Name of the student
        int age = 20;                         // Age of the student
        double gpa = 2.56;                    // Grade Point Average (GPA) of the student
        char gender = 'M';                    // Gender of the student ('M' for Male, 'F' for Female)
        boolean isForeigner = false;          // Foreigner status (true if foreigner, false otherwise)
        int studentID = 38;               // Student ID

        // Display the student details
        System.out.println("Student Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("GPA: " + gpa);
        System.out.println("Gender: " + gender);
        System.out.println("Foreigner: " + isForeigner);
        System.out.println("Student ID: " + studentID);
    }
}

