class task1{
    //Create a java file output data
    public static void main(String[] args){
        System.out.println("//////////////////////////////");
        System.out.println("     Student Points      **");
        System.out.println("///////////////////////////////");
        System.out.println("Lab       Bonus    Total");
        System.out.println("43         7         50");
        System.out.println("50         8         58");
        System.out.println("39         10        49");
    }
}