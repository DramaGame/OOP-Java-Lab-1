class task2{//explain the code detail
    public static void main(String[] args){
    System.out.println("This is a long string that is the "+
    "concatenation of two shorter strings.");/*
    the two sentence combine together in QUOTATION MARK symbole
    */
    System.out.println("This first computer was invented about"+ 55 +
    "Years ago.");/*
    without space in one QUOTATION MARK of sentence to order QUOTATION MARK of sentence
    */
    System.out.println("8 Plus 4 is " + 8+5);/*FIrst display the sentence who write in  
    FIrst display the sentence who write in  
    QUOTATION MARK and second is write number 85  */
    System.out.println("8 Plus 5 is " + (8+5) );/*FIrst display the sentence who write in  
    QUOTATION MARK and second is add the number who is burter (8+5) answer =13 */
    System.out.println(8+5 + "equals 8 plus 5. ");/*First add two number is 8+5 answer :13 
    without space the second display the sentence who write in QUOTATION MARK  */
    }
}
    

