class task4{
    //display the (10+5)*(4-6)/4
    public static void main(String[] args){
        System.out.println("(10+5)*(4-6)/4");
    }
}